export interface User {
  id: string;
  email: string;
  createdAt: FirebaseFirestore.Timestamp;
}